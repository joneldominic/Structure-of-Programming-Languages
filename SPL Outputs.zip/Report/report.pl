/*
 * Jonel Dominic Tapang BSCS-3
 */

%Facts
food(burger).
food(sandwich).
food(pizza).

human(jonel).
human(paul).
human(christian).
human(venz).
human(tabada).
human(regis).

subject(cs135).
subject(cs138).
subject(cs139).
subject(cs133).
subject(cs122).
subject(cs124).

studies(jonel, cs124).
studies(jonel, cs139).
studies(paul, cs135).
studies(christian, cs122).

teacher(tabada, cs139).
teacher(tabada, cs138).
teacher(tabada, cs135).
teacher(tabada, cs133).
teacher(regis, cs124).
teacher(regis, cs122).


%Rules
student(Name):-human(Name).

teacher(Name):-human(Name).

professor(X, Y):- teacher(X, Z),
                  studies(Y, Z).
