/*
 *Jonel Dominic Tapang
 *BSCS - 3
 *This is my 1st Prolog Program
 */

%facts about students and their subject
studies(jonel, cs124).
studies(paul, cs138).
studies(christian, cs124).
studies(venz, cs139).


%facts about teachers and the subject they are teaching
teaches(kirke, cs128).
teaches(collins, cs138).
teaches(collins, cs139).
teaches(juniper, cs124).


%rules about the professor
professor(X, Y) :-teaches(X, C), studies(Y, C).
%X is professor of Y if X teaches C and Y studies C


%get the sum of A and B and return it in Sum
sum(A,B, Sum) :-  Sum is A+B.

%get the produc of A and B and return it in X
multiply(A,B,X):- X is A*B.



/*
 * This code is equal to C++ code below:
 * if (A==2){cout<<"A = 2";}
 * else if(A==3){cout<<"A = 3;}
 * else {cout<<"A is neither 2 or 3"}
 */
check(A):- (A =:= 2 -> writeln('A is 2');
           A =:= 3 -> writeln('A is 3');
           writeln('A is neither 2 or 3')).


/*
 * This code is equal to C++ code below:
 * while(N>0){
 *     cout<<"Number: "<<N<<endl;
 *     N--;
 * }
 */
while(0).
while(N) :- N>0,
            write('Number: '),
            write(N), nl, M is N-1,
            while(M).

/*
 * This code is equal to C++ code below:
 * for(int i = Counter, i<End, i+=Step){
 *     cout<<"Counter is: "<<i<<endl;
 * }
 */
for_loop(Counter, End, Step) :- Counter =< End,
                                write('Counter is: '), write(Counter), nl,
                                Counter1 is Counter + Step,
                                for_loop(Counter1, End, Step).


human(jonel).
student(Sname):-human(Sname).


/*
 * This code is equal to C++ code below:
 * char Ans;
 * do{
 *   cout<<"\nPrint this message again? ([y]es/[n]o) ";
 *   cin>>Ans;
 * }while(Ans == 'y');
 */
do_while :-
  nl,
  writeln('Welcome.'),
  repeat,
  writeln('Print this message again? ([y]es/[n]o)'),
  read(Ans),nl,
  (Ans == y ->
    writeln('You selected yes.'),
    fail % backtrack to repeat
  ; writeln('You selected no.'),
    ! % cut, we won't backtrack to repeat anymore
  ).


who_am_I:- writeln('Who are you?'), read(Name), nl,
             write('Hi!, '), write(Name), nl.
