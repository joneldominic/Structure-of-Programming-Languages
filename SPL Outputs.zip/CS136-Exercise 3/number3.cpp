#include <iostream>

using namespace std;

#define LoopCount 5

int main(){
    int i=0;

    for(int i=0; i<=LoopCount; i++){
        if(i==5){
            cout<<"Value of variable i (Inside for statement): "<<i<<endl;
        }
    }

    cout<<"Value of variable i (After for statement): "<<i<<endl<<endl;

    if(i==LoopCount){
        cout<<">>Variable i inside \"for statement\" is visible after the body of \"for statement\""<<endl;
    }
    else{
        cout<<">>Variable i inside \"for statement\" is not visible after the body of \"for statement\""<<endl;
    }


    return 0;
}
