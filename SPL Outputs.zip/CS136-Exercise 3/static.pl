$a = 0;
sub foo {
  return $a;
}
sub staticScope {
  my $a = 1;
  return foo();
}

print staticScope(); 
