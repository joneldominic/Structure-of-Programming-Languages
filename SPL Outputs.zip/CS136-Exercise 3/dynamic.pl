$x = 0;
sub bar {
  return $x;
}
sub dynamicScope {
  local $x = 1;
  return bar();
}
print dynamicScope();
