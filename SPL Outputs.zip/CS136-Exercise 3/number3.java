/**
 * @(#)number3.java
 *
 *
 * @author Tapang
 * @version 1.00 2018/4/13
 */

public class number3 {
        
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    	final int LoopCount = 5;
    	int i=0;
    	
    	int innerVariHolder  = 0;
    	
    	for(i=0; i<=LoopCount; i++){
    		if(i==5){
    			innerVariHolder = i;
    			System.out.println("Value of variable i (Inside for statement): " + i);
    		}
    	}
    	
    	if(i==LoopCount){
    		System.out.println("Variable i inside \"for statement\" is visible after the body of \"for statement\"");
    	}
    	else{
    		System.out.println("Variable i inside \"for statement\" is not visible after the body of \"for statement\"");
    	}
    	
    }
}

/*
  int i=0;

    for(int i=0; i<=LoopCount; i++){
        if(i==5){
            cout<<"Value of variable i (Inside for statement): "<<i<<endl;
        }
    }

    cout<<"Value of variable i (After for statement): "<<i<<endl<<endl;

    if(i==LoopCount){
        cout<<">>Variable i inside \"for statement\" is visible after the body of \"for statement\""<<endl;
    }
    else{
        cout<<">>Variable i inside \"for statement\" is not visible after the body of \"for statement\""<<endl;
    }

 */