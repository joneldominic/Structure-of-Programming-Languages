#include <stdio.h>

int main(){

    return 0;
}


void myCFunction(){
    x=21;
    int x;
    x=42;
}

