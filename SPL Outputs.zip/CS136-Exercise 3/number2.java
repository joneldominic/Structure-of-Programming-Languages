/**
 * @(#)number2.java
 *
 *
 * @author 
 * @version 1.00 2018/4/13
 */

public class number2 {
        
    /**
     * Creates a new instance of <code>number2</code>.
     */
    public number2() {
    }
    
    public void myJavaFunction(){
    	x = 21;
		int x;
		x = 42;
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
}
